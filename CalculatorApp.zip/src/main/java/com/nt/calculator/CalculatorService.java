package com.nt.calculator;

/**
 * This is the Interface that provide methodd declaration for Calculator 
 * Application
 * @author vinay
 *
 */
public interface CalculatorService {
	
	public long addTwoNumber(long first,long second);
	public long subTwoNumber(long first,long second);
	public long mulTwoNumber(long first,long second);
	public double divTwoNumber(double first,double second);

}//CalculatorService 

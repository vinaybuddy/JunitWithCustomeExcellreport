package com.nt.calculator;

/**
 * This the implementation class of CalculatorService interface provide simple
 * calculation(add,sub,div,smul) functionalty
 * 
 * @author vinay
 *
 */
public class CalculatorServiceImpl implements CalculatorService {

	/**
	 * this method is perform addition operation
	 * 
	 * @see com.nt.calculator.CalculatorService#addTwoNumber(java.lang.long,
	 *      java.lang.long)
	 * @param first
	 * @param second
	 * @return long
	 * 
	 */
	@Override
	public long addTwoNumber(long first, long second) {
		/*if (first <= 0 || second <= 0)
			throw new IllegalArgumentException("please Enter positive and greator then 0 number");*/
		return first + second;
	}// addTwoNumber(-,-)

	/**
	 * this method is perform substraction operation
	 * 
	 * @see com.nt.calculator.CalculatorService#subTwoNumber(java.lang.long,
	 *      java.lang.long)
	 * @param first
	 * @param second
	 * @return long
	 * 
	 */
	@Override
	public long subTwoNumber(long first, long second) {
		/*if(first<=0||second<=0) 
			throw new IllegalArgumentException("please Enter positive and greator then 0 number");*/
		return first-second;
	}// subTwoNumber(-,-)

	/**
	 * this method is perform multiplecation operation
	 * 
	 * @see com.nt.calculator.CalculatorService#mulTwoNumber(java.lang.long,
	 *      java.lang.long)
	 * @param first
	 * @param second
	 * @return long
	 * 
	 */
	@Override
	public long mulTwoNumber(long first, long second) {
		/*if(first<=0||second<=0) 
			throw new IllegalArgumentException("please Enter positive and greator then 0 number");
*/		return first*second;
	}// mulTwoNumber(-,-)

	/**
	 * this method is perform division operation
	 * 
	 * @see com.nt.calculator.CalculatorService#divTwoNumber(java.lang.long,
	 *      java.lang.long)
	 * @param first
	 * @param second
	 * @return long
	 * 
	 */
	@Override
	public double divTwoNumber(double first, double second) {
		if(second<=0) 
			throw new IllegalArgumentException("please Enter positive and greator then 0 number");
		return first/second;
	}// divTwoNumber(-,-)

}// class

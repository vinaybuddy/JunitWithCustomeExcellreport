package com.nt.test;

import static org.junit.Assert.assertEquals;


import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.nt.calculator.CalculatorService;
import com.nt.calculator.CalculatorServiceImpl;

/**
 * Junit test class for Calculator Application
 * @author vinay
 *
 */
public class CalculatorTest {
	private  static CalculatorService service;
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		service=new CalculatorServiceImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
		service=null;
	}

	
	@Test()
	//@Ignore
	public void addNumbertestWithSmallInteger() {
		long expected=0;
		long actual=0;
		expected=50;
		actual=service.addTwoNumber(20, 30);
		assertEquals("addNumbertestWithBigInteger", expected, actual);
		
	}//addNumbertestWithSmallInteger()
	
	@Test
	public void addNumbertestWithBigInteger() {
		long expected=0;
		long actual=0;
		expected=230999000;
		actual=service.addTwoNumber(200000000,30999000);
		assertEquals("addNumbertestWithBigInteger", expected, actual);
	}//addNumbertestWithBigInteger
	

	@Test
	public void subNumbertestWithSmallInteger() {
		long expected=0;
		long actual=0;
		expected=-24;
		actual=service.subTwoNumber(65, 89);
		assertEquals("subNumbertestWithBigInteger", expected, actual);
		
	}//subNumbertestWithSmallInteger()
	
	@Test
	public void subNumbertestWithBigInteger() {
		long expected=0;
		long actual=0;
		expected=169001000;
		actual=service.subTwoNumber(200000000,30999000);
		assertEquals("subNumbertestWithBigInteger", expected, actual);
	}//subNumbertestWithBigInteger
	
	
	@Test
	public void mulNumbertestWithSmallInteger() {
		long expected=0;
		long actual=0;
		expected=17290;
		actual=service.mulTwoNumber(38, 455);
		assertEquals("mulNumbertestWithBigInteger", expected, actual);
		
	}//mulNumbertestWithSmallInteger()
	
	@Test
	public void mulNumbertestWithBigInteger() {
		long expected=0;
		long actual=0;
		expected=61800000;
		actual=service.mulTwoNumber(20000,3090);
		assertEquals("mulNumbertestWithBigInteger", expected, actual);
	}//mulNumbertestWithBigInteger

	@Test
	public void divNumbertestWithSmallInteger() {
		double expected=0;
		double actual=0;
		expected=19.5;
		actual=service.divTwoNumber(78, 4);
		assertEquals("divNumbertestWithBigInteger", expected, actual,0);
		
	}//mulNumbertestWithSmallInteger()
	
	@Test
	public void divNumbertestWithBigInteger() {
		double expected=0;
		double actual=0;
		expected=6.4724919094;
		actual=service.divTwoNumber(20000,3090);
		assertEquals("divNumbertestWithBigInteger", expected, actual,4);
	}//divNumbertestWithBigInteger
	
	@Test(expected=IllegalArgumentException.class)
	public void divNumbertestWithZero() {
		double expected=0;
		double actual=0;
		expected=6.4724919094;
		actual=service.divTwoNumber(20000,0);
		assertEquals("divNumbertestWithBigInteger", expected, actual,4);
	}//divNumbertestWithBigInteger


}// CalculatorTest
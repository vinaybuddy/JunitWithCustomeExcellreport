package com.nt.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses(value= {CalculatorTest.class,CalculatorAdditionParameterizedTest.class,CalculatorSubstractionParameterizedTest.class,CalculatorMultiplecationParameterizedTest.class})
public class CalculatorTestSuit{

}//CalculatorTestSuit

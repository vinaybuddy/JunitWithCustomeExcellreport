package com.nt.test;





import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.nt.calculator.CalculatorService;
import com.nt.calculator.CalculatorServiceImpl;

/**
 * JUnit test class for parameterized Calculator Application testing
 * @author vinay
 *
 */
@RunWith(value = Parameterized.class)
public class CalculatorMultiplecationParameterizedTest {
	private   CalculatorService service;
	private long firstNumber;
	private long secondNumber;
	private long expectedResult;
	
	
	public CalculatorMultiplecationParameterizedTest(long firstNumber, long secondNumber, long expectedResult) {
		this.firstNumber = firstNumber;
		this.secondNumber = secondNumber;
		this.expectedResult = expectedResult;
	}


	@Before
	public void calculatorInitlizer( ) {
		service=new CalculatorServiceImpl();
	}
	

	@After
	public  void UnInitlize() throws Exception {
		service=null;
	}

	
	@Parameters()
	public static Collection input() {
		return Arrays.asList(new Object[][] { {50,36,1800} , {-36,25,-900} ,  {74,-13,-962} ,  {-34,-22,748}, {0,0,0} });
		
	}//input()
	@Test
	public void mulNumbertestWithDiferentParameters() {
		long expected=0;
		long actual=0;
		expected=expectedResult;
		actual=service.mulTwoNumber(firstNumber,secondNumber);
		assertEquals("mulNumbertestWithDiferentParameters", expected, actual);
		
	}//mulNumbertestWithDiferentParameters()
	
	
	

	

}// CalculatorTest
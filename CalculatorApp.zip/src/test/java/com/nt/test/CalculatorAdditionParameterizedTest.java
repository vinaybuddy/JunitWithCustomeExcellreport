package com.nt.test;





import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.nt.calculator.CalculatorService;
import com.nt.calculator.CalculatorServiceImpl;

/**
 * JUnit test class for parameterized Calculator Application testing
 * @author vinay
 *
 */
@RunWith(value = Parameterized.class)
public class CalculatorAdditionParameterizedTest {
	private   CalculatorService service;
	private long firstNumber;
	private long secondNumber;
	private long expectedResult;
	
	
	public CalculatorAdditionParameterizedTest(long firstNumber, long secondNumber, long expectedResult) {
		this.firstNumber = firstNumber;
		this.secondNumber = secondNumber;
		this.expectedResult = expectedResult;
	}


	@Before
	public void calculatorInitlizer( ) {
		service=new CalculatorServiceImpl();
	}
	

	@After
	public  void UnInitlize() throws Exception {
		service=null;
	}

	
	@Parameters()
	public static Collection input() {
		return Arrays.asList(new Object[][] { {50,36,86} , {-36,25,-11} ,  {74,-13,61} ,  {-34,-22,-56}, {0,0,0} });
		
	}//input()
	@Test
	public void addNumbertestWithDiferentParameters() {
		long expected=0;
		long actual=0;
		expected=expectedResult;
		actual=service.addTwoNumber(firstNumber,secondNumber);
		assertEquals("addNumbertestWithDiferentParameters", expected, actual);
		
	}//addNumbertestWithDiferentParameters()
	
	
	

	

}// CalculatorTest
package com.nt.test;





import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.nt.calculator.CalculatorService;
import com.nt.calculator.CalculatorServiceImpl;

/**
 * JUnit test class for parameterized Calculator Application testing
 * @author vinay
 *
 */
@RunWith(value = Parameterized.class)
public class CalculatorDivisionParameterizedTest {
	private   CalculatorService service;
	private long firstNumber;
	private long secondNumber;
	private long expectedResult;
	
	
	public CalculatorDivisionParameterizedTest(long firstNumber, long secondNumber, long expectedResult) {
		this.firstNumber = firstNumber;
		this.secondNumber = secondNumber;
		this.expectedResult = expectedResult;
	}


	@Before
	public void calculatorInitlizer( ) {
		service=new CalculatorServiceImpl();
	}
	

	@After
	public  void UnInitlize() throws Exception {
		service=null;
	}

	
	@Parameters()
	public static Collection input() {
		return Arrays.asList(new Object[][] { {536,5,2680} });
		
	}//input()
	@Test()
	public void divNumbertestWithDiferentParameters() {
		double expected=0;
		double actual=0;
		expected=expectedResult;
		actual=service.divTwoNumber(firstNumber,secondNumber);
		assertEquals("divNumbertestWithDiferentParameters", expected, actual,4);
		
	}//mulNumbertestWithDiferentParameters()
	
	
	

	

}// CalculatorTest